package boot.mvc.ex1;

import lombok.Data;

@Data
public class ShopDto {
	
	private String sang;
	private int su;
	private int dan;

}
