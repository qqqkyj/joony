package boot.mvc.ex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEx1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
