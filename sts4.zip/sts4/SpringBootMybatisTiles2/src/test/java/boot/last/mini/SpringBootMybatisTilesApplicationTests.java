package boot.last.mini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMybatisTilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
