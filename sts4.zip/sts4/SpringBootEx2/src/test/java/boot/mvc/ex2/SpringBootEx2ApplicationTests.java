package boot.mvc.ex2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEx2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
