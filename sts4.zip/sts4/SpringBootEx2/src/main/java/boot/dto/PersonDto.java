package boot.dto;

import lombok.Data;

@Data
public class PersonDto {
	
	private String name;
	private String addr;
	private String hp;
	
}
