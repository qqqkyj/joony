package boot.mini.chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootChattingApplicationTests {

	@Test
	void contextLoads() {
	}

}
