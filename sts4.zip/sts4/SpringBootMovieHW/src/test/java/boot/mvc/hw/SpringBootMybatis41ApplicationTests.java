package boot.mvc.hw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMybatis41ApplicationTests {

	@Test
	void contextLoads() {
	}

}
