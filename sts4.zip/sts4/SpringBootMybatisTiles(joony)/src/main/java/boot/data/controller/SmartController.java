package boot.data.controller;

public class SmartController {

}
